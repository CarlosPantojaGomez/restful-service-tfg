package com.uma.tfg.repositories;

import java.util.List;
import org.springframework.data.repository.CrudRepository;

import com.uma.tfg.entities.User;


public interface UserRepository extends CrudRepository<User, Long> {

    List<User> findByEmail(String email);

    User findByNickname(String nickname);
    
    User findByNicknameAndPassword(String nickname, String password);
}
