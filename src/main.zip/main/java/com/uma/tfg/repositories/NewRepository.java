package com.uma.tfg.repositories;

import org.springframework.data.repository.CrudRepository;

import com.uma.tfg.entities.New;

public interface NewRepository extends CrudRepository<New, Long>  {

}
