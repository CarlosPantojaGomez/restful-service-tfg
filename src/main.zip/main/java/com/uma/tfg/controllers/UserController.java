package com.uma.tfg.controllers;

import com.uma.tfg.entities.User;
import com.uma.tfg.services.UserService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*", methods= {RequestMethod.GET,RequestMethod.POST,RequestMethod.PUT, RequestMethod.DELETE})
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/user")
    public void createUser(@RequestBody User user) throws Exception {
        userService.createUser(user);
    }
    
    @GetMapping("/user/authenticate/{nickname}/{password}")
    public User AuthUser(@PathVariable String nickname, @PathVariable String password) throws Exception {
        
    	return userService.getByNicknameAndPassword(nickname,password);
        
    }

    @PutMapping("/user")
    public void updateUser(@RequestBody User user) throws Exception {
        userService.createUser(user);
    }

    @GetMapping("/user/{id}")
    public User getUser(@PathVariable Long id) throws Exception {
        return userService.getUser(id);
    }

    @GetMapping("/user/findEmail/{email}")
    public List<User> getUserByEmail(@PathVariable String email) throws Exception {
        return userService.getByEmail(email);
    }

    @GetMapping("/user/findNickname/{nickname}")
    public User getUserByNickname(@PathVariable String nickname) throws Exception {
        return userService.getByNickname(nickname);
    }

    @GetMapping("/users")
    public List<User> all() {
        return userService.getAll();
    }

    @DeleteMapping("/user/delete/{id}")
    public void deleteUser(@PathVariable Long id) throws Exception {
        userService.delete(id);
    }
}